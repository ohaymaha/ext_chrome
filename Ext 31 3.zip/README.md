## Phiên bản hiện tại
Phiên bản Beta 1.6
Cập nhật: 10h:52  27/02/2015

## Cập nhật Beta 1.6
- Thêm tính năng đa ngôn ngữ

## Cập nhật Beta 1.5
- Fix lỗi mất events js khi chèn từ khoá

## Cập nhật Beta 1.4
- Dùng publisher xử lý content web
- Đồng bộ đăng nhập, chuyển đăng nhập và đăng ký về trang chủ OHM

## Cập nhật Beta 1.3
- Chuyển sang dùng JSONP

## Cập nhật Beta 1.2
- Fix đồng bộ đăng nhập với trang chủ OHM 
- Thêm trang adv.ohm.vn, oad.ohm.vn vào list không hiệu lực extension

## Cập nhật Beta 1.1
- Đồng bộ đăng nhập với trang chủ OHM
- Ap dụng list các trang của OHM hoặc các trang là Publisher của OHM không hiệu lực extension
- Đưa quản lý màu sắc OTA lên popup, bổ sung các link điều hướng về trang chủ OHM trên popup
- Fix lỗi kích thước popup khi sử dụng

## Giới thiệu
Extension của OHM dành cho trình duyệt Chrome. Dụng cụ để khai thác OTA (Ô TRI ÂN) của công ty OHM.
